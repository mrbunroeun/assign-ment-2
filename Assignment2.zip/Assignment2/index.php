<!DOCTYPE html>
<html>
<head>
    <title>Student Management</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .error { color: red; }
    </style>
</head>
<body>

<?php
class Student {
    public $name;
    public $id;
    public $grade;

    public function __construct($name, $id, $grade) {
        $this->name = $name;
        $this->id = $id;
        $this->grade = $grade;
    }
}

session_start();
if (!isset($_SESSION['students'])) {
    $_SESSION['students'] = [];
}

$name = $id = $grade = "";
$nameErr = $idErr = $gradeErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add'])) {
        if (empty($_POST["name"])) {
            $nameErr = "Name is required";
        } else {
            $name = htmlspecialchars($_POST["name"]);
        }
        if (empty($_POST["id"])) {
            $idErr = "ID is required";
        } else {
            $id = htmlspecialchars($_POST["id"]);
        }
        if (empty($_POST["grade"])) {
            $gradeErr = "Grade is required";
        } else {
            $grade = htmlspecialchars($_POST["grade"]);
        }

        if (empty($nameErr) && empty($idErr) && empty($gradeErr)) {
            $student = new Student($name, $id, $grade);
            $_SESSION['students'][] = $student;
        }
    } elseif (isset($_POST['delete'])) {
        $deleteId = $_POST['delete'];
        foreach ($_SESSION['students'] as $key => $student) {
            if ($student->id == $deleteId) {
                unset($_SESSION['students'][$key]);
                break;
            }
        }
    } elseif (isset($_POST['edit'])) {
        $editId = $_POST['edit'];
        foreach ($_SESSION['students'] as $key => $student) {
            if ($student->id == $editId) {
                $name = $student->name;
                $id = $student->id;
                $grade = $student->grade;
                break;
            }
        }
    } elseif (isset($_POST['update'])) {
        $updateId = $_POST['update'];
        foreach ($_SESSION['students'] as $key => $student) {
            if ($student->id == $updateId) {
                $_SESSION['students'][$key]->name = htmlspecialchars($_POST["name"]);
                $_SESSION['students'][$key]->id = htmlspecialchars($_POST["id"]);
                $_SESSION['students'][$key]->grade = htmlspecialchars($_POST["grade"]);
                break;
            }
        }
    }
}
?>

<div class="form-container">
    <h2>Add/Edit Student</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $name; ?>">
        <span class="error"><?php echo $nameErr; ?></span><br><br>

        <label for="id">ID:</label>
        <input type="text" id="id" name="id" value="<?php echo $id; ?>">
        <span class="error"><?php echo $idErr; ?></span><br><br>

        <label for="grade">Grade:</label>
        <input type="text" id="grade" name="grade" value="<?php echo $grade; ?>">
        <span class="error"><?php echo $gradeErr; ?></span><br><br>

        <?php if (isset($_POST['edit'])): ?>
            <input type="hidden" name="update" value="<?php echo $_POST['edit']; ?>">
            <input type="submit" name="update" value="Update Student">
        <?php else: ?>
            <input type="submit" name="add" value="Add Student">
        <?php endif; ?>
    </form>
</div>

<h2>Student List</h2>
<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>ID</th>
            <th>Grade</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($_SESSION['students'] as $student): ?>
            <tr>
                <td><?php echo $student->name; ?></td>
                <td><?php echo $student->id; ?></td>
                <td><?php echo $student->grade; ?></td>
                <td>
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" style="display: inline;">
                        <input type="hidden" name="delete" value="<?php echo $student->id; ?>">
                        <input type="submit" name="delete" value="Delete">
                    </form>
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" style="display: inline;">
                        <input type="hidden" name="edit" value="<?php echo $student->id; ?>">
                        <input type="submit" name="edit" value="Edit">
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>